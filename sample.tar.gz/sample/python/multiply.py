import ducktape

@ducktape.main("int","int", "int")
def multiply(first,second):
	return first*second 

