Run the ducktape using : 

java -jar Platform.jar [options...] [input file (default:workflow.yaml)]
 --domainpath VAL                      : A directory containing source code and
                                         resources to be loaded. Each source
                                         file should be in a directory that
                                         matches the name of its controller
                                         (ie. java files should be in a
                                         directory called 'java'). (default:
                                         none)
 --output FILE                         : The output directory (default: the
                                         working directory)
 --profile [LOCAL | THREADED | HADOOP] : Execution profile to be used LOCAL
                                         THREADED HADOOP (default: LOCAL)


Example:

java -jar Platform.jar --domainpath . --output result workflows/count.yaml
